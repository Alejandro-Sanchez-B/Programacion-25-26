/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sanchez_barroso_alejandro_examen2;

/**
 *
 * @author alumno
 */
public interface Pedaleable {
    //Creamos los metodos que heredarás las clases hijas
    public void sprintar();
    public void atacar();
    public float recuperar (float kmDeRecuperacion);
}
